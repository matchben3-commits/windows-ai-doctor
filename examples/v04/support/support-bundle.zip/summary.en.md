# Windows AI Doctor — Support summary

This is a limited support summary. Review it before sharing; it is not sent automatically. Diagnostic signals may still be linkable. No original path mapping is available. Configuration, logs, credentials, original report text and raw output are omitted; no new scan was performed. Counts are not a health score; skipped or unknown checks are not passes.

Pass: 1 · Warning: 0 · Error: 2 · Unknown: 0 · Not checked: 1

| ID | Status | Limited observations |
| --- | --- | --- |
| codex.config.user | Error | {} |
| codex.path | Pass | {"installation_groups": 1, "scan_limited": false} |
| codex.version | Error | {"version": "1.2.1"} |
| scope.unchecked | Not checked | {} |
