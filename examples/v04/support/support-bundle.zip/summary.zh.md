# Windows AI Doctor — 求助摘要

这是用于求助的有限摘要，请自行审阅后分享；不会自动发送。不保证任意诊断信号都无法关联。无原始路径映射。未收录配置、日志、凭据、原报告文字和原始输出；未做新扫描。状态数量不是健康评分，未检查或未知不代表通过。

通过: 1 · 提醒: 0 · 异常: 2 · 无法判断: 0 · 未检查: 1

| ID | 状态 | 有限观察 |
| --- | --- | --- |
| codex.config.user | 异常 | {} |
| codex.path | 通过 | {"installation_groups": 1, "scan_limited": false} |
| codex.version | 异常 | {"version": "1.2.1"} |
| scope.unchecked | 未检查 | {} |
